package demo;

import akka.Done;
import akka.NotUsed;
import akka.actor.ActorSystem;
import akka.http.javadsl.Http;
import akka.http.javadsl.model.StatusCodes;
import akka.http.javadsl.model.ws.Message;
import akka.http.javadsl.model.ws.TextMessage;
import akka.http.javadsl.model.ws.WebSocketRequest;
import akka.http.javadsl.model.ws.WebSocketUpgradeResponse;
import akka.japi.Pair;
import akka.stream.ActorMaterializer;
import akka.stream.javadsl.Flow;
import akka.stream.javadsl.Keep;
import akka.stream.javadsl.Sink;
import akka.stream.javadsl.Source;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;

import java.util.concurrent.CompletionStage;

public class ChirperHistoryWebSocket {
    private final ActorSystem actorSystem = ActorSystem.create();
    private final ActorMaterializer actorMaterializer = ActorMaterializer.create(actorSystem);
    private final Http http = Http.get(actorSystem);

    public static void main(String[] args) {
        new ChirperHistoryWebSocket().run();
    }

    private void run() {
        userActivityHistoryStream("luke");
        userActivityHistoryStream("han");
        userActivityHistoryStream("lela");
        userActivityHistoryStream("obiWan");
    }

    private void userActivityHistoryStream(String userId) {
        final Source<Message, NotUsed> source = Source.single(TextMessage.create(""));

        // Remember something similar from the 1st exercise
        final Sink<Entity.Chirp, CompletionStage<Done>> sink =
                Sink.foreach(chirp -> System.out.println(String.format("History(%s): %s", userId, chirp)));

        // Create a websocket request object using the api location
        final WebSocketRequest webSocketRequest = WebSocketRequest.create(String.format("ws://localhost:9000/api/activity/%s/history", userId));

        // This is streaming of course, so we need to create a flow
        final Flow<Message, Message, CompletionStage<WebSocketUpgradeResponse>> webSocketClientFlow = http.webSocketClientFlow(webSocketRequest);

        // Now we need to connect and run the stream
        final Pair<CompletionStage<WebSocketUpgradeResponse>, CompletionStage<Done>> pair =
                source.viaMat(webSocketClientFlow, Keep.right())
                        //.via(TBD)
                        .toMat(sink, Keep.both())
                        .run(actorMaterializer);

        // The remote shoudl reply with an upgrade response, we need that to decide what to do next
        final CompletionStage<WebSocketUpgradeResponse> upgradeResponseCompletionStage = pair.first();

        //the second part of the tuple will complete with this is closed.
        final CompletionStage<Done> closed = pair.second();

        //this will complete if the response is connected without issue, or throw exception if not connected
        final CompletionStage<Done> connected = upgradeResponseCompletionStage
                .thenApply(upgrade -> {
                    if (upgrade.response().status().equals(StatusCodes.SWITCHING_PROTOCOLS)) {
                        return Done.getInstance();
                    } else {
                        throw new RuntimeException("Connection failed: " + upgrade.response().status());
                    }
                });

        //when connected is completed, we'll get a happy message.
        connected.thenAccept(done -> System.out.println(String.format("Connected to live stream for user %s", userId)));

        //when closed is completed, we'll say goodbye to the world.
        closed.thenAccept(done -> {
            System.out.println(String.format("Close live stream for user %s", userId));
            actorSystem.terminate();
            System.exit(0);
        });
    }

    private static Flow<Message, Entity.Chirp, NotUsed> messageToChirpFlow() {
        final ObjectMapper objectMapper = new ObjectMapper();
        final ObjectReader readChirp = objectMapper.readerFor(Entity.Chirp.class);

        // This flow transforms a ws message to a string
        final Flow<Message, String, NotUsed> messageToString = Flow.of(Message.class).map(message -> message.asTextMessage().getStrictText());

        // This flow transforms a string to a chirp
        final Flow<String, Entity.Chirp, NotUsed> jsonToChirp = Flow.of(String.class).map(readChirp::<Entity.Chirp>readValue);

        //todo One of these flows needs to be run via the other
        return null;
    }
}
