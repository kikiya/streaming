exercise_00_initial_state

This exercise shows a simple RESTful API that is Asynchronous and 
non-blocking. 

First, take a look at the WalletService interface found here:
com.example.wallet.api.WalletService

Here you will find 