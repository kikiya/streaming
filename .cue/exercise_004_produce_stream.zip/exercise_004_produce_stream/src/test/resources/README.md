exercise_01_produce_stream

This exercise we will be opening a web-socket to produce a stream of
content from the opened socket. 

The content will be printed to console. 

You could also issue commands to change the state of your entities 
using the open socket.