/*
 * 
 */
package com.example.wallet.impl;

import akka.Done;
import akka.NotUsed;
import akka.stream.javadsl.Source;
import com.example.wallet.api.WalletService;
import com.lightbend.lagom.javadsl.api.ServiceCall;

import static java.util.concurrent.CompletableFuture.completedFuture;

/**
 * Implementation of the WalletService.
 */
public class WalletServiceImpl implements WalletService {

  @Override
  public ServiceCall<NotUsed, String> balance(String id) {
    return request -> completedFuture(String.format("Where's %s's money!?", id));
  }

  @Override
  public ServiceCall<Source<String, ?>, Done> produce() {
    return words -> null;

  }



}
