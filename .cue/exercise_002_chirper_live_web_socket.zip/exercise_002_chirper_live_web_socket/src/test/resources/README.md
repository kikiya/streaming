exercise_002_chirper_live_web_socket

# Kept Live Web Socket Example

## Description
In this final Akka Http part, we will be showing connecting to a live socket that stays 
open to keep getting chirps. 

In the first exercises, you'll notice that when the data is finished, the socket closes.

Here, there are some changes made to make sure the socket stays open even when there is no data.

### Step 3.a (review code)
Find the method `private void userActivityLiveStream(String userId)`

You'll see that it is very similar to the historical chirps version that we just finished.
With one exception:

```
// using Source.maybe materializes into a completable future
// which will allow us to complete the source later
final Flow<Message, Message, CompletableFuture<Optional<Message>>> flow =
  Flow.fromSinkAndSourceMat(
    Sink.foreach(System.out::println),
    Source.maybe(),
    Keep.right());
```
### Step 3.b (homework: update code)
Find method `private Flow<Message, Entity.Chirp, NotUsed> messageToChirpFlow()`

Remember this? 

Homework - how would you change this to filter out bad words? (like "foo") 